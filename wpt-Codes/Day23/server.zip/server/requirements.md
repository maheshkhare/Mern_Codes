#### User

- signup
- signin
- confirm account
- forgot password
- reset password
- profile

#### security

- JWT

#### Products

- create
- get
- search
- edit
- delete

#### Categories

- create
- get
- edit
- delete

#### Companies

- create
- get
- edit
- delete

#### Cart

- create
- get
- edit
- delete

#### Orders

- create
- get
- cancel

#### Payment

- create
- get
- edit
- delete
